<?php ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1); ?>
<?php
  session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
        <link href="../styles.css" rel="stylesheet" crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-default">
              <div class="container-fluid">
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="#">Журнал нагрузки</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav">
                    <li><a href="/index.php">Главная</a></li>
                    <li><a href="/Department.php">Кафедра</a></li>
                    <li><a href="/Teacher.php">Преподаватель</a></li>
                    <li><a href="/Group.php">Группы</a></li>
                    <li><a href="/Work_fact.php">Занятие факт</a></li>
                    <li><a href="/Work_plane.php">Заниятие план</a></li>
                    <li><a href="/Type_of_work.php">Тип занятия</a></li>
                  </ul>
                  <div class="pull-right">
                    <?php if(isset($_SESSION['login'])) { ?>
                      <p>Пользователь: <?php echo $_SESSION['login'];  ?></p>
                      <p><a href="logout.php">Выйти</a></p>
                    <?php } ?>
                  </div>
                </div>
              </div>
          </nav>
        </header>


        <div class="container-fluid">
            <?php include '../db.php'; ?>
            <?php include '../api.php'; ?>
            <?php
                        $login = $_SESSION['login'];
                        $p1 = $_POST['Full_name'];
                        $p2 = $_POST['Academic_degree'];
                        $p3 = $_POST['Mail'];
                        $p4 = $_POST['Tel_number'];
                        $p5 = $_POST['About'];
                        $p6 = $_POST['Publications'];
                        $p7 = $_POST['Disciplines'];
                        $p8 = $_POST['S_activity'];
                        $p9 = $_POST['P_competencions'];
                        $p10 = $_POST['Qualification'];
                        $p11 = $_POST['Position'];
                        saveTeach_lk($db, $login, $p1, $p2, $p3, $p4, $p5, $p6, $p7, $p8, $p9, $p10, $p11);
                        header("Location: edit_lk.php");
             ?>

        </div>

        <footer>

        </footer>
    </body>