<?php

	session_start();
	include '../db.php';
	include '../api.php';

	if(!empty($_POST)) {

		if($_POST['login'] != '' && $_POST['password'] != '') {
			$login = trim(strip_tags($_POST['login']));
			$password = trim(strip_tags($_POST['password']));
			if(isUser($db, $login, $password)) {
				$_SESSION['login'] = $login;
			} else {
				echo "<h3>Пользатель не найден</h1>";	
			}
		} else {
			echo "<h3>Заполните все поля</h1>";
		}

	}
?>
<?php ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Document</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="../styles.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>

<header>
    <nav class="navbar navbar-default" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Журнал нагрузки</a>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="/index.php">Главная</a></li>
                    <li><a href="/Department.php">Кафедра</a></li>
                    <li><a href="/Teacher.php">Преподаватель</a></li>
                    <li><a href="/Group.php">Группы</a></li>
                    <li><a href="/Work_fact.php">Занятие факт</a></li>
                    <li><a href="/Work_plane.php">Заниятие план</a></li>
                    <li><a href="/Type_of_work.php">Тип занятия</a></li>
                </ul>
                <div class="pull-right">
						<?php if(isset($_SESSION['login'])) { ?>
							<p>Пользователь: <?php echo $_SESSION['login'];  ?></p>
							<p><a href="logout.php">Выйти</a></p>
						<?php } ?>
					</div>
            </div>
        </div>
    </nav>
</header>

<div id="content">
		<div class="container-fluid">
		<?php if(!isset($_SESSION['login'])) { ?>
			<form action="" method="POST" role="form">
			
				<div class="form-group">
					<label for="">Логин</label>
					<input type="text" class="form-control" id="login" name="login">
				</div>

				<div class="form-group">
					<label for="">Пароль</label>
					<input type="password" class="form-control" id="password" name="password">
				</div>
			
				<button type="submit" class="btn btn-primary">Войти</button>
			</form>
			<p><a href="register.php">Нет аккаунта?</a></p>
		<?php } 
		else { ?>
			<div class="content">
				<section class="main">
					<div class="row">
						<div class="lk_menu col-md-3">
							<ul class="lk_item">
								<li><a href="Beography.php">Биография</a></li>
								<li><a href="Publications.php">Публикации</a></li>
								<li><a href="Disciplines.php">Преподаваемые дисциплины</a></li>
								<li><a href="S_activity.php">Научная деятельность</a></li>
								<li><a href="P_competencions.php">Проффесиональная компетенция</a></li>
								<li><a href="Qualification.php">Повышение квалификации</a></li>
								<li><a href="Publications.php">Расписание</a></li>
							</ul>
						</div>
						<?php
							$login = $_SESSION['login'];
							$info = getTeachName($db , $login);
							$Be = getTeachBe($db , $login);
							?>
					
							<div class="card col-md-9">
								<div class="row">
									<div class="col-md-3" style="background: #f0f0f0; height: 350px">
										<img src="<?php echo  $info['Img']; ?>" alt="">
									</div>
								<div class="info col-md-9">
									<h2><?php echo  $info['Full_name']; ?></h2>
									<h5>Ученая степень:  <?php echo  $info['Academic_degree']; ?></h5>
									<h5>Должность:  <?php echo  $info['Position']; ?></h5>
									<h5>Эл.почта:  <?php echo  $info['Mail']; ?></h5>
									<h5>Тел:  <?php echo  $info['Tel_number']; ?></h5>
									<a href="edit_lk.php">Настройки</a>
								</div>
								</div>
								</div>
							</div>
					<div class="row">
				</section>
				<div class="col-md-offset-3">
						<p class="info_block_tab">Публикации</p>
						<div class="info_block">
							<p><?php echo  $Be['Publications']; ?></p>
						</div>
				</div>
				</div>
			</div>
		 <?php } ?>
		</div>
		
	</div>

<footer>
</footer>
</body>
</html>